# Finished_login ReadMe
( Finished all things of login and signup. )
SEE the FILE NAME "b07FinalProject_Group9_updateAug1st"
This File is the complete version of the login and signup pages.
