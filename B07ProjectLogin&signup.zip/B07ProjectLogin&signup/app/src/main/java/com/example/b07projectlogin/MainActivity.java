package com.example.b07projectlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickShopperLogin(View view){
        Intent intent = new Intent(this, ShopperLoginActivity.class);
        startActivity(intent);
    }

    public void onClickShopperSignup(View view){
        Intent intent = new Intent(this, ShopperSignupActivity.class);
        startActivity(intent);
    }

    public void onClickOwnerLogin(View view){
        Intent intent = new Intent(this, OwnerLoginActivity.class);
        startActivity(intent);
    }

    public void onClickOwnerSignup(View view){
        Intent intent = new Intent(this, OwnerSignupActivity.class);
        startActivity(intent);
    }


}