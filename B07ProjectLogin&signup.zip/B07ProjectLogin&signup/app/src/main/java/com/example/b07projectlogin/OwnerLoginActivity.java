package com.example.b07projectlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OwnerLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ownerlogin);
    }
}