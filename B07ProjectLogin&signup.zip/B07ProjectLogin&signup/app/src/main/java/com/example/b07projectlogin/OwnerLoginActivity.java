package com.example.b07projectlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;

public class OwnerLoginActivity extends AppCompatActivity {

    private Spinner spinner;

    public void backToMain(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    private void openShopperSignup(){
        Intent intent = new Intent(this,ShopperSignupActivity.class);
        startActivity(intent);
    }

    private void openOwnerLogin(){
        Intent intent = new Intent(this,OwnerLoginActivity.class);
        startActivity(intent);
    }

    private void openOwnerSignup(){
        Intent intent = new Intent(this,OwnerSignupActivity.class);
        startActivity(intent);
    }

    private void  openShopperLogin(){
        Intent intent = new Intent(this, ShopperLoginActivity.class);
        startActivity(intent);
    }
    private void setSpinner(){
        spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setSelection(2);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ownerlogin);
        setSpinner();
        spinnerMethod();

    }

    public void spinnerMethod(){
        spinner=(Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //open another activity
                if(spinner.getSelectedItem().toString().contains("shopper signup")){
                    openShopperSignup();
                }

//                if(spinner.getSelectedItem().toString().contains("owner login")){
//                    openOwnerLogin();
//                }

                if(spinner.getSelectedItem().toString().contains("owner signup")){
                    openOwnerSignup();
                }

                if(spinner.getSelectedItem().toString().contains("shopper login")){
                    openShopperLogin();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Nothing
            }
        });

    }
}