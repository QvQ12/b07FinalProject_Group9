package com.b07finalproject_group9.objects;

public class StoreProduct {
    String name;
    int quantity;
    double price;
    String description;
    public StoreProduct(String n, int q, double p, String d)
    {
        name = n;
        quantity = q;
        price = p;
        description = d;
    }
}
