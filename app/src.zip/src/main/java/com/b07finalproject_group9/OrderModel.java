package com.b07finalproject_group9;

import com.google.firebase.database.DatabaseReference;

import java.util.HashMap;

public class OrderModel extends DatabaseModel{



}
