package com.b07finalproject_group9;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;


public class ShoppingCart extends AppCompatActivity {

    private RecyclerView shoppingCartRecyclerView;
    private ItemProductAdapter adapter;
    private List<Product> products = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_shopping_cart);

        shoppingCartRecyclerView = findViewById(R.id.shoppingCartRecyclerView);

        // TODO: Populate the products list with your data here

        adapter = new ItemProductAdapter(products);
        shoppingCartRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        shoppingCartRecyclerView.setAdapter(adapter);

        Button returnToMainButton = findViewById(R.id.button);
        returnToMainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ShoppingCart.this, com.tempfragments.ShopperDashboard.class));
            }
        });

        Button payOrderButton = findViewById(R.id.payOrderButton);
        payOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ShoppingCart.this, ShopperOrder.class));
            }
        });
    }

    // Assuming you have the Product and ItemProductAdapter classes somewhere either in separate files or in this file.
}
