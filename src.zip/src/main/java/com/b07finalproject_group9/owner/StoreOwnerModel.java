package com.b07finalproject_group9.owner;

import com.b07finalproject_group9.DatabaseModel;

public class StoreOwnerModel extends DatabaseModel {
}
