package com.b07finalproject_group9.objects;

public class StoreProduct {
}
