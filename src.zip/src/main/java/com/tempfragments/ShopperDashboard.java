package com.tempfragments;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Button;  // Import for the Menu button
import android.content.Intent;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.b07finalproject_group9.R;

import com.b07finalproject_group9.login.OwnerLoginFragment;
import com.b07finalproject_group9.login.OwnerSignUpFragment;
import com.b07finalproject_group9.login.ShopperLoginFragment;
import com.b07finalproject_group9.login.ShopperSignUpFragment;
import com.google.firebase.FirebaseApp;

public class ShopperDashboard extends AppCompatActivity {

    private ImageView tShirtsImage;
    private ImageView shoppingCartImage;
    private ImageView readyForPickUpImage;
    private Button menuButton;  // Declaration for the Menu button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_shopper_dashboard);

        tShirtsImage = findViewById(R.id.t_shirts);
        shoppingCartImage = findViewById(R.id.shopping_cart);
        readyForPickUpImage = findViewById(R.id.ready_for_pick_up);
        menuButton = findViewById(R.id.button);  // Initialization for the Menu button.

        tShirtsImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the ProductExample activity when tShirtsImage is clicked
                startActivity(new Intent(ShopperDashboard.this, com.b07finalproject_group9.ProductExample.class));
            }
        });

        shoppingCartImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the ShoppingCart activity when shoppingCartImage is clicked
                startActivity(new Intent(ShopperDashboard.this, com.b07finalproject_group9.ShoppingCart.class));
            }
        });

        readyForPickUpImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the ShopperOrder activity when readyForPickUpImage is clicked
                startActivity(new Intent(ShopperDashboard.this, com.b07finalproject_group9.ShopperOrder.class));
            }
        });

        // Set the onClick listener for the Menu button to open MainActivity
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ShopperDashboard.this, com.b07finalproject_group9.MainActivity.class);
                startActivity(intent);
            }
        });
    }
}